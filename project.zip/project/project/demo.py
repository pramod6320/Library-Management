import array as arr
def test(nums):
    return sorted(set(nums),key=nums.index)
arry_num =arr.array('i',[10,11,12,13,14,16,17,18,19,11])
print("original array:")
for i in range(len(arry_num)):
    print(arry_num[i] , end=" ")
print("\n after removing duplicate array",test(arry_num))
