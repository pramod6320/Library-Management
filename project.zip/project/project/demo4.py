from array import*

def largest(arr,n):
    max = arr[0]
    
    for i in range(1,n):
        if arr[i] > max:
            max =arr[i]
    return max

arr= array("i",[])
x=int(input("enter a size  of array"))
for i in range(x):
    n=int(input("enter the no"))
    arr.append(n)
ans = largest(arr,x)
print("largest is", ans)