from django.contrib import admin
from .models import Book,LabAdmin

@admin.register(Book)
class UserAdmin(admin.ModelAdmin):
    list_display =('id','s_name','b_id','b_name')
    
@admin.register(LabAdmin)
class LabAdmin(admin.ModelAdmin):
    list_display=('email','password')
