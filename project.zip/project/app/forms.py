import email
from pyexpat import model
from tkinter import Label
from attr import field
from click import password_option
from django import forms
from django.forms import widgets
from . models import Book, LabAdmin

class TaskRegistration(forms.ModelForm):
    class Meta:
        model = Book
        fields =['s_name','b_id','b_name',]
        labels ={'s_name':'Student Name','b_id':'Book Id','b_name':'Book Name'}
        widgets ={
            's_name': forms.TextInput(attrs={'class':'form-control'}),
            'b_id': forms.TextInput(attrs={'class':'form-control'}),
            'b_name': forms.TextInput(attrs={'class':'form-control'})
        
        }
        
class AdminFrom(forms.ModelForm):
    class Meta:
        model = LabAdmin
        fields =['email','password']
        
        widgets={
            'email':forms.EmailInput(attrs={'class':'form-control'}),
            'password':forms.TextInput(attrs={'class':'form-control'})
        }