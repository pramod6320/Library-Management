from django.shortcuts import render, HttpResponseRedirect
from .forms import TaskRegistration,AdminFrom
from . models import Book
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.shortcuts import redirect, render

# Create your views here.
def add_show(request):
    if request.method == 'POST':
        fm = TaskRegistration(request.POST)
        if fm.is_valid():
            fm.save()
        fm = TaskRegistration()
    else:
        fm = TaskRegistration()
    stud = Book.objects.all()

    return render(request,'enroll/addandShow.html',{'form':fm,'stu':stud})

def edit_data(request ,id):
    if request.method == 'POST':
        pi = Book.objects.get(pk=id)
        fm = TaskRegistration(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = Book.objects.get(pk=id)
        fm = TaskRegistration(instance=pi)

    return render(request,'enroll/update.html',{'form':fm})

#this fuction is delete function
def delete_data(request, id):
    if request.method == 'POST':
        pi = Book.objects.get(pk=id)
        pi.delete()
        
        return HttpResponseRedirect('/')

def admin(request):
    if request.method == 'POST':
        afm = AdminFrom(request.POST)
        if afm.is_valid():
            afm.save()
        afm = AdminFrom()
    else:
        afm = AdminFrom()
        
    
    return render(request,'enroll/admin.html',{'new':afm})

#login page
def singup(request):

    if request.method == "POST":


        # username =request.POST.get('username' ) 
        username =request.POST['username']
        email =request.POST['email']
        pass1 =request.POST['pass1']

        myuser = User.objects.create_user(username,email,pass1)
        
        myuser.save()

        messages.success(request,"yuor acoount has been successfully create ")

        # return redirect('/singin')
    return render(request,'enroll/singup.html')

def singin(request):
    if request.method =='POST':
        username = request.POST['username']
        pass1 = request.POST['pass1']

        user = authenticate(username=username, password=pass1)

        if user is not None:
            login(request, user)
            return render(request,'enroll/addandShow.html')
        else:
            messages.error(request,'red')
            # return redirect('singup')
    return render(request,'enroll/admin.html')

