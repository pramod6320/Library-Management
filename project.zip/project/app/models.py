import email
from hashlib import new
from pyexpat import model
from django.db import models

# Create your models here.
class Book(models.Model):
    id=models.IntegerField(primary_key=True)
    s_name= models.CharField(max_length=100,default="")
    b_id= models.CharField(max_length=100,default="")
    b_name= models.CharField(max_length=100,default="")
   
class LabAdmin(models.Model):
    email=models.EmailField(max_length=100)
    password=models.CharField(max_length=100) 